Update 1.3
- Each variant now has additional animations for two kinds of rifle. 
  Each has shooting, crouch-shooting and running animations.


Update 1.2
- Hazmat variants added
- Survivor added
- Ninja added
- Tactical variants added


Update 1.1
- Spacesuit added
- Spacesuit /no helmet added
- Overalls set added





This zip contains 4 folders seperating the sprites into skin tones - light, medium, dark and grey.

Inside each folder are 15 different variations on the same animation set, each has been created from a combination of clothing and given its own colour scheme.

Each of these folders contains a PNG sequence of the animation set. 

The animations are as follows:

- Standing

- Crouching

- Running

- Jumping forward (rising, falling and landing)

- Jumping in place (rising, falling and landing)

- Two punch combo

- Being hit

- Falling backwards

- Falling over/Dying

- Shooting a pistol (standing)

- Running with a pistol

- Sword strike (standing)

- Sword strike (moving)


Each animation has been separated by a blank frame in between.


I have also included the .gal file these images were created in. 
This file can opened with GraphicsGale and edited further to create your own combinations or customizations, although recolouring will be left to you.

Thanks for giving this pack a shot, I hope you find it useful.

 - Drasnus